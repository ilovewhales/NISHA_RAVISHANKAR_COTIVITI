"""
Clinical Note Analyzer — Cotiviti Internship POC
Topic 1: Clinical NLP using LLMs

Usage:
    1. Install dependencies:  pip install anthropic reportlab python-docx pypdf
    2. Set your API key:      export ANTHROPIC_API_KEY="sk-ant-..."
    3. Run:                   python clinical_note_analyzer.py

When prompted, drag and drop your .pdf or .docx file into the terminal,
or type the full file path manually.

Each run saves a uniquely named PDF report in the same folder as this script.
"""

import os
import json
import anthropic
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                 Table, TableStyle, HRFlowable)
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import Flowable

# ── Colors ────────────────────────────────────────────────────────────────────
NAVY   = colors.HexColor("#0A2342")
BLUE   = colors.HexColor("#065A82")
TEAL   = colors.HexColor("#1C7293")
MINT   = colors.HexColor("#02C39A")
LIGHT  = colors.HexColor("#EDF6FA")
BORDER = colors.HexColor("#B8D8E8")
MUTED  = colors.HexColor("#607D8B")
TEXT   = colors.HexColor("#1A2B3C")
WHITE  = colors.white
PURPLE = colors.HexColor("#4A235A")
RED    = colors.HexColor("#A0003A")
ORANGE = colors.HexColor("#FFF8EE")

# ── Custom Flowables ──────────────────────────────────────────────────────────
class TwoColorRule(Flowable):
    def __init__(self, w, c1, c2, h=3):
        Flowable.__init__(self); self.width=w; self.c1=c1; self.c2=c2; self.height=h
    def draw(self):
        m=self.width*0.45
        self.canv.setFillColor(self.c1); self.canv.rect(0,0,m,self.height,stroke=0,fill=1)
        self.canv.setFillColor(self.c2); self.canv.rect(m,0,self.width-m,self.height,stroke=0,fill=1)

class SecHeader(Flowable):
    def __init__(self, title, w, bg=None):
        Flowable.__init__(self); self.title=title; self.width=w; self.bg=bg or NAVY; self.height=26
    def draw(self):
        c=self.canv
        c.setFillColor(self.bg); c.roundRect(0,0,self.width,self.height,4,stroke=0,fill=1)
        c.setFillColor(MINT);    c.roundRect(0,0,5,self.height,2,stroke=0,fill=1)
        c.setFillColor(WHITE);   c.setFont("Helvetica-Bold",11); c.drawString(14,8,self.title.upper())


# ── File reading ──────────────────────────────────────────────────────────────
def read_pdf(path: str) -> str:
    from pypdf import PdfReader
    reader = PdfReader(path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() + "\n"
    return text.strip()


def read_docx(path: str) -> str:
    from docx import Document
    doc = Document(path)
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def load_note(path: str) -> str:
    path = path.strip().strip("'\"")   # handle drag-and-drop quotes on Mac
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        print("  Reading PDF...")
        return read_pdf(path)
    elif ext in (".docx", ".doc"):
        print("  Reading Word document...")
        return read_docx(path)
    else:
        raise ValueError(f"Unsupported file type '{ext}'. Please use a .pdf or .docx file.")


# ── Claude API ────────────────────────────────────────────────────────────────
PROMPT_TEMPLATE = """You are a clinical NLP system. Analyze the following clinical note
and extract structured information. Respond ONLY with a valid JSON object,
no markdown, no backticks, no preamble.

JSON format:
{{
  "diagnoses": [{{"name": "string", "icd_hint": "string"}}],
  "procedures": ["string"],
  "medications": [{{"name": "string", "dose": "string"}}],
  "entities": [{{"label": "string", "value": "string"}}],
  "summary": "2-3 sentence plain English summary of this note"
}}

Clinical note:
{note}"""


def analyze_note(note: str) -> dict:
    client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=4096,
        messages=[{"role": "user", "content": PROMPT_TEMPLATE.format(note=note)}]
    )
    raw = message.content[0].text.strip()
    # Strip any accidental markdown fences
    raw = raw.replace("```json", "").replace("```", "").strip()
    return json.loads(raw)


# ── PDF report ───────────────────────────────────────────────────────────────
def build_pdf(data: dict, note: str, source_filename: str, out_path: str) -> None:
    W = letter[0] - 1.4*inch

    def sty(name, **kw): return ParagraphStyle(name, **kw)
    lbl  = sty("lbl",  fontSize=8,  textColor=MUTED,  fontName="Helvetica-Bold", spaceAfter=0, leading=11)
    val  = sty("val",  fontSize=10, textColor=TEXT,   fontName="Helvetica",       spaceAfter=0, leading=13)
    bul  = sty("bul",  fontSize=10, textColor=TEXT,   fontName="Helvetica",       leading=15,   spaceAfter=2)
    foot = sty("foot", fontSize=8,  textColor=MUTED,  fontName="Helvetica",       alignment=TA_CENTER)
    hosp = sty("hosp", fontSize=20, textColor=NAVY,   fontName="Helvetica-Bold",  alignment=TA_CENTER, spaceAfter=1, spaceBefore=0)
    dept = sty("dept", fontSize=9,  textColor=MUTED,  fontName="Helvetica",       alignment=TA_CENTER, spaceAfter=4, spaceBefore=0)
    summ = sty("summ", fontSize=10, textColor=TEXT,   fontName="Helvetica",       leading=16)
    cc   = sty("cc",   fontSize=11, textColor=TEXT,   fontName="Helvetica-Bold",  leading=16, leftIndent=6)

    def th(text, bg=NAVY):
        return Paragraph(f"<b>{text}</b>", sty("th"+text[:4], fontSize=9, textColor=WHITE, fontName="Helvetica-Bold"))
    def tc(text, bold=False, color=None):
        fn = "Helvetica-Bold" if bold else "Helvetica"
        return Paragraph(text, sty("tc"+text[:5], fontSize=10, textColor=color or TEXT, fontName=fn, leading=14))

    BASE_TS = lambda bg: TableStyle([
        ("BACKGROUND",    (0,0),(-1,0),  bg),
        ("TEXTCOLOR",     (0,0),(-1,0),  WHITE),
        ("FONTNAME",      (0,1),(-1,-1), "Helvetica"),
        ("FONTSIZE",      (0,0),(-1,-1), 10),
        ("ROWBACKGROUNDS",(0,1),(-1,-1), [LIGHT, WHITE]),
        ("TEXTCOLOR",     (0,1),(-1,-1), TEXT),
        ("GRID",          (0,0),(-1,-1), 0.4, BORDER),
        ("TOPPADDING",    (0,0),(-1,-1), 6),
        ("BOTTOMPADDING", (0,0),(-1,-1), 6),
        ("LEFTPADDING",   (0,0),(-1,-1), 10),
        ("LINEAFTER",     (0,0),(0,-1),  1.5, MINT),
    ])

    ts_str = datetime.now().strftime("%B %d, %Y at %I:%M %p")
    doc = SimpleDocTemplate(out_path, pagesize=letter,
        leftMargin=0.7*inch, rightMargin=0.7*inch,
        topMargin=0.4*inch, bottomMargin=0.5*inch)
    story = []

    # Header — navy banner with title inside
    header_table = Table([
        [Paragraph("CLINICAL NOTE ANALYZER",
                   sty("ht", fontSize=20, textColor=WHITE, fontName="Helvetica-Bold", alignment=TA_CENTER, spaceAfter=0))],
        [Paragraph(f"Cotiviti Internship POC  ·  Source: {source_filename}  ·  {ts_str}",
                   sty("hd", fontSize=9, textColor=colors.HexColor("#A8CDE0"), fontName="Helvetica", alignment=TA_CENTER, spaceAfter=0))]
    ], colWidths=[W])
    header_table.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), NAVY),
        ("TOPPADDING",    (0,0), (-1,-1), 10),
        ("BOTTOMPADDING", (0,0), (-1,-1), 10),
        ("LEFTPADDING",   (0,0), (-1,-1), 12),
        ("RIGHTPADDING",  (0,0), (-1,-1), 12),
        ("LINEBELOW",     (0,-1),(-1,-1), 3, MINT),
    ]))
    story += [header_table, Spacer(1,10)]

    # Patient info from entities
    entities = data.get("entities", [])
    def get_ent(label):
        for e in entities:
            if e.get("label","").lower() == label.lower():
                return e.get("value","—")
        return "—"

    info = [("PATIENT", get_ent("Patient Name")), ("MRN", get_ent("MRN")),
            ("DATE",    get_ent("Admission Date")), ("ATTENDING", get_ent("Attending Physician")),
            ("ALLERGY", get_ent("Allergy")), ("REFERRING", get_ent("Referring Physician"))]
    irows = []
    for i in range(0, len(info), 2):
        irows.append([Paragraph(info[i][0],lbl),   Paragraph(info[i][1],val),
                      Paragraph(info[i+1][0],lbl), Paragraph(info[i+1][1],val)])
    it = Table(irows, colWidths=[W*0.14, W*0.36, W*0.14, W*0.36])
    it.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4)]))
    story += [it, Spacer(1,10), HRFlowable(width=W,thickness=0.5,color=BORDER,spaceAfter=12)]

    # Vitals from entities
    vital_keys = [("Blood Pressure","BP"),("Heart Rate","HR"),
                  ("Respiratory Rate","Resp."),("O2 Saturation","O₂ Sat"),
                  ("Temperature","Temp"),("Weight","Weight")]
    vitals = [(short, get_ent(full)) for full,short in vital_keys]
    story += [SecHeader("Vital Signs", W, bg=BLUE), Spacer(1,6)]
    vr = [[Paragraph(l, lbl) for l,v in vitals],
          [Paragraph(v, sty(f"vv{i}", fontSize=11, textColor=BLUE, fontName="Helvetica-Bold", leading=14))
           for i,(l,v) in enumerate(vitals)]]
    vt = Table(vr, colWidths=[W/6]*6)
    vt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),LIGHT),
        ("TOPPADDING",(0,0),(-1,-1),6),("BOTTOMPADDING",(0,0),(-1,-1),6),
        ("LEFTPADDING",(0,0),(-1,-1),8),
        ("LINEABOVE",(0,0),(-1,0),2,MINT),("LINEBELOW",(0,-1),(-1,-1),2,TEAL),
        ("INNERGRID",(0,0),(-1,-1),0.5,BORDER)]))
    story += [vt, Spacer(1,12)]

    # Summary
    story += [SecHeader("Plain-English Summary", W, bg=colors.HexColor("#028090")), Spacer(1,6)]
    st = Table([[Paragraph(data.get("summary","No summary generated."), summ)]], colWidths=[W])
    st.setStyle(TableStyle([("BACKGROUND",(0,0),(0,0),LIGHT),
        ("TOPPADDING",(0,0),(0,0),10),("BOTTOMPADDING",(0,0),(0,0),10),
        ("LEFTPADDING",(0,0),(0,0),12),("RIGHTPADDING",(0,0),(0,0),12),
        ("LINEBELOW",(0,0),(0,0),2,MINT)]))
    story += [st, Spacer(1,14)]

    # Diagnoses
    story += [SecHeader("Diagnoses", W, bg=NAVY), Spacer(1,6)]
    diagnoses = data.get("diagnoses", [])
    dd = [[th("Diagnosis"), th("ICD-10 Hint"), th("Type")]]
    for i, d in enumerate(diagnoses):
        dtype = "Primary" if i == 0 else "Chronic"
        dd.append([tc(d.get("name",""), bold=True, color=BLUE),
                   tc(d.get("icd_hint","—")), tc(dtype)])
    if not diagnoses:
        dd.append([tc("None identified."), tc(""), tc("")])
    dt = Table(dd, colWidths=[W*0.55, W*0.25, W*0.20])
    dt.setStyle(BASE_TS(NAVY))
    story += [dt, Spacer(1,14)]

    # Medications
    story += [SecHeader("Medications", W, bg=TEAL), Spacer(1,6)]
    medications = data.get("medications", [])
    md = [[th("Medication",bg=TEAL), th("Dose / Frequency",bg=TEAL), th("Route",bg=TEAL)]]
    for m in medications:
        is_new = "iv" in m.get("dose","").lower() or "new" in m.get("dose","").lower()
        color = RED if is_new else None
        bold  = is_new
        md.append([tc(m.get("name",""), bold=bold, color=color),
                   tc(m.get("dose","—"),  bold=bold, color=color),
                   tc("IV — NEW" if is_new else "Oral", bold=bold, color=color)])
    if not medications:
        md.append([tc("None identified."), tc(""), tc("")])
    mts = BASE_TS(TEAL)
    mt = Table(md, colWidths=[W*0.30, W*0.45, W*0.25])
    mt.setStyle(mts)
    story += [mt, Spacer(1,14)]

    # Procedures
    story += [SecHeader("Procedures / Orders", W, bg=colors.HexColor("#1B4F72")), Spacer(1,6)]
    procedures = data.get("procedures", [])
    if procedures:
        prows = [[Paragraph(f"• {p}", bul)] for p in procedures]
        pt = Table(prows, colWidths=[W])
        pt.setStyle(TableStyle([
            ("ROWBACKGROUNDS",(0,0),(-1,-1),[LIGHT,WHITE]),
            ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
            ("LEFTPADDING",(0,0),(-1,-1),10),
            ("GRID",(0,0),(-1,-1),0.4,BORDER)]))
        story.append(pt)
    else:
        story.append(Paragraph("None identified.", bul))
    story.append(Spacer(1,14))

    # Key Entities
    story += [SecHeader("Key Entities Extracted", W, bg=PURPLE), Spacer(1,6)]
    half = (len(entities)+1)//2
    le = entities[:half]; re = entities[half:]
    while len(re) < len(le): re.append({"label":"","value":""})
    edata = [[th("Label",bg=PURPLE), th("Value",bg=PURPLE),
              th("Label",bg=PURPLE), th("Value",bg=PURPLE)]]
    for L, R in zip(le, re):
        edata.append([Paragraph(L.get("label",""), lbl), Paragraph(L.get("value",""), val),
                      Paragraph(R.get("label",""), lbl), Paragraph(R.get("value",""), val)])
    ets = BASE_TS(PURPLE)
    ets.add("FONTNAME",(0,1),(0,-1),"Helvetica-Bold")
    ets.add("FONTNAME",(2,1),(2,-1),"Helvetica-Bold")
    ets.add("TEXTCOLOR",(0,1),(0,-1),PURPLE)
    ets.add("TEXTCOLOR",(2,1),(2,-1),PURPLE)
    et = Table(edata, colWidths=[W*0.15, W*0.35, W*0.15, W*0.35])
    et.setStyle(ets)
    story += [et, Spacer(1,20)]

    # Footer
    story += [TwoColorRule(W,NAVY,MINT,2), Spacer(1,6),
              Paragraph(f"Generated by Clinical Note Analyzer POC  ·  Nisha Ravishankar  ·  Cotiviti Internship Assessment  ·  {ts_str}", foot)]
    doc.build(story)

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    print("\n" + "═" * 55)
    print("   CLINICAL NOTE ANALYZER  —  Cotiviti POC")
    print("═" * 55)

    # Check API key
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("\n  ERROR: ANTHROPIC_API_KEY not set.")
        print("   Run:  export ANTHROPIC_API_KEY='sk-ant-...'")
        return

    # Ask user for file
    print("\nSupported formats: .pdf  .docx")
    print("Tip (Mac): drag and drop your file into this terminal window.\n")
    file_path = input("Enter path to clinical note file: ").strip().strip("'\"")

    if not os.path.exists(file_path):
        print(f"\n  File not found: {file_path}")
        return

    # Load note text
    try:
        note = load_note(file_path)
        if not note:
            print("  Could not extract any text from the file. Is it scanned/image-only?")
            return
        print(f"  ✓ Loaded {len(note.split())} words from '{os.path.basename(file_path)}'")
    except ValueError as e:
        print(f"\n  {e}")
        return

    # Analyze
    print("\nSending to Claude for analysis...")
    try:
        result = analyze_note(note)
    except json.JSONDecodeError as e:
        print(f"  Failed to parse Claude's response: {e}")
        return
    except anthropic.APIError as e:
        print(f"  Anthropic API error: {e}")
        return

    # Print to terminal
    print("\n" + "─" * 55)
    print("🩺  DIAGNOSES")
    for d in result.get("diagnoses", []):
        icd = f"  [{d.get('icd_hint','')}]" if d.get("icd_hint") else ""
        print(f"  • {d.get('name','')}{icd}")

    print("\n  PROCEDURES")
    for p in result.get("procedures", []):
        print(f"  • {p}")

    print("\n  MEDICATIONS")
    for m in result.get("medications", []):
        print(f"  • {m.get('name','')} — {m.get('dose','')}")

    print("\n  KEY ENTITIES")
    for e in result.get("entities", []):
        print(f"  • {e.get('label','')}: {e.get('value','')}")

    print(f"\n SUMMARY\n  {result.get('summary','')}")
    print("─" * 55)

    # Save PDF
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    source_name = os.path.basename(file_path)
    out_dir = os.path.dirname(os.path.abspath(__file__))
    pdf_path = os.path.join(out_dir, f"clinical_report_{ts}.pdf")

    build_pdf(result, note, source_name, pdf_path)
    print(f"\n  PDF saved to: {pdf_path}\n")


if __name__ == "__main__":
    main()